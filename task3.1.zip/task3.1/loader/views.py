from flask import Blueprint, render_template, request
from functions import get_posts, add_post


loader_blueprint = Blueprint(
	'loader_blueprint', 
	__name__,
  template_folder='templates')


@loader_blueprint.route("/post", methods=["GET", "POST"])
def post():
    if request.method == 'GET':
        return render_template('post_form.html')
    elif request.method == 'POST':
        picture = request.files.get("picture")
        content = request.form.get('content')

        if picture and content and  (picture.content_type == 'image/png' or picture.content_type == 'image/jpeg'):
            filename = picture.filename
            picture.save(f"./uploads/images/{filename}")
            post = {'pic':f"/uploads/images/{filename}", 'content': content}    
            add_post(post)    
            return render_template('post_uploaded.html', post=post)
        else:
            return 'Ошибка загрузки<br><a href="/"> Назад </a>'
@loader_blueprint.route('/search/')
def search():
    s = request.args['s']
    posts = get_posts(s)
    return render_template('post_list.html', s=s, posts=posts)