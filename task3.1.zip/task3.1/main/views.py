from flask import Blueprint, render_template, request
from functions import get_posts


main_blueprint = Blueprint(
	'main_blueprint', 
	__name__,
  template_folder='templates', static_folder='static')


@main_blueprint.route('/')
def index():
    return render_template('index.html')

@main_blueprint.route('/search/')
def search():
    s = request.args['s']
    posts = get_posts(s)
    return render_template('post_list.html', s=s, posts=posts)

